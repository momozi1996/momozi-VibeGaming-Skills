# Assets and dependency notices

All scene geometry, texture canvases, weapon models, soldiers, interface design, and synthesized sound in this project are original procedural work in `src/`. No assets or code from Valve / Counter-Strike / CS2 are included. Product names describe inspiration only and remain their owners' trademarks.

- Three.js 0.180.0 — MIT, https://github.com/mrdoob/three.js ; runtime renderer and geometry utilities. Full license included below.
- Vite 6.3.5 — MIT, https://github.com/vitejs/vite ; development/build tooling, not a runtime service.
- Playwright 1.55.0 — Apache-2.0, https://github.com/microsoft/playwright ; test tooling, not shipped as runtime code.
- Fonts are system fonts (Arial/Impact and fallbacks); no font files are redistributed.

## Three.js license

The MIT License

Copyright © 2010-2025 three.js authors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
